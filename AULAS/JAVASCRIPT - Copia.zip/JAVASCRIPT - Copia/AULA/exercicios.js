var n1= 10;
var n2= 3;
var n3= 50;
var n4= 5;
var n5= 100;
var n6= 35;

var multiplicacao = n1*n2
var divisao = n3/n4
var soma = n1+n2+n3+n4
var divisao1 = 68/4
var quadrado = n6/n5
var multiplicacao1 = n3*n3
var retangulo = n1*n4



console.log(multiplicacao)
console.log(divisao)
console.log(soma)
console.log(divisao1)
console.log(quadrado)
console.log(multiplicacao1)
console.log(retangulo)