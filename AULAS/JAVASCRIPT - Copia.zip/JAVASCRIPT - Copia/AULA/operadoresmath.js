var n1= 50;
var n2= 30;
var soma=n1+n2
var subtracao=n1-n2
var multiplicacao=n1*n2
var divisao=n1/n2

console.log(soma)
console.log(subtracao)
console.log(multiplicacao)
console.log(divisao)
