const wendy = 50
console.log(wendy)