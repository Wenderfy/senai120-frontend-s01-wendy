let nome = "Maria"

if (nome == "Maria") {
    console.log("Igual Maria")
}
    
else {
    console.log("Diferente de Maria")
}