let idade1 = 14

if (idade1 >=16 && idade1 <=17) {
    console.log("Você pode votar");
}
else if (idade1 >=18 && idade1 <=59) {
    console.log("Você é obrigado a votar");
}
else {
    console.log("Você não pode votar")
}
