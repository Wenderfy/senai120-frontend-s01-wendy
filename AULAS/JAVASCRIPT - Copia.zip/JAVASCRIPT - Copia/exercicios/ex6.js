var n1 = 69.28
var n2 = 64
var n3 = 5

var multiplicacao = n1*n1