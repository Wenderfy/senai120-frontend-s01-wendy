let idade = 27

if (idade >= 18) {
    console.log("Você é maior de idade");
}
else {
    console.log("Você não é maior de idade");
}
