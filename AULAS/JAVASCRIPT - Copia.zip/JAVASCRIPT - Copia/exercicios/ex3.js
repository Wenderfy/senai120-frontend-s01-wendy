let numero1=10
let numero2=20
let numero3=30

if (numero3 =30) {
    console.log("Maior número")
}

else {
    console.log("Menor número")
}