let num = -7

if (num >= 0) {
    console.log("O número é positivo");
}

else {
    console.log("O número é negativo");
}