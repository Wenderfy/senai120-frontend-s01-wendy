let numero = 10

if (numero % 2 == 0) {  //qualquer número divido por 2 ou 0 é par
    console.log("O número é par");
}

else {
    console.log("O número é impar");
}
